//
//  QSPreferenceVC.h
//  TestSystem
//
//  Created by SW05 on 12/21/15.
//  Copyright © 2015 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QSPreferenceVC : NSViewController

@end
