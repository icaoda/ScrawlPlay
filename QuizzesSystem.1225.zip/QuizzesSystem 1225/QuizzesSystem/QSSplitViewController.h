//
//  ViewController.h
//  QuizzesSystem
//
//  Created by SW05 on 12/5/15.
//  Copyright © 2015 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QSSplitViewController : NSSplitViewController

@end

