//
//  ToolBox.h
//  KanZH_Startpage
//
//  Created by SW05 on 5/4/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ToolBox : NSObject

/* ** 为字符串计算容器Label的高度
 @para: str--   内容字符串
 @para: width-- 容器的宽度
 @para: size--  字体的值
 @return: Label的高度
 */
+ (CGFloat)toolCalcHeightForString:(NSString *)str Width:(CGFloat)width fontSize:(CGFloat)size;
/* ** 通过距离RTC的秒数，计算当期日期的
 @para: str--   总共秒数的值
 @return: 格式化的日期字串，这里用“MM-dd hh:mm:ss”
 */
+ (NSString *)toolGetDateFromString:(NSString *)str;

@end
