//
//  Header.h
//  KanZH_Startpage
//
//  Created by SW05 on 5/4/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#ifndef Header_h
#define Header_h

#define kScreenSize [UIScreen mainScreen].bounds.size
#define kCellSpace 8.0



#endif /* Header_h */
