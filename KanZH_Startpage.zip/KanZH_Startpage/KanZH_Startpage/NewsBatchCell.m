//
//  NewsBatchCell.m
//  KanZH_Startpage
//
//  Created by SW05 on 5/4/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import "NewsBatchCell.h"
#import "NewsBatch.h"
#import "Header.h"
#import "ToolBox.h"

@interface NewsBatchCell ()
@property (weak, nonatomic) IBOutlet UIImageView *newsImg;
@property (weak, nonatomic) IBOutlet UIImageView *badget;
@property (weak, nonatomic) IBOutlet UILabel *newsExcerpt;
@property (weak, nonatomic) IBOutlet UILabel *pubTime;
@property (weak, nonatomic) IBOutlet UILabel *newsCount;

@end

@implementation NewsBatchCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Auto resize to screen size
    CGRect rect = self.frame;
    rect.size.width = kScreenSize.width;
    self.frame = rect;
}

- (void)showCellWithNewsBatch:(NewsBatch *)newsBatch {
    // ** 1.设置图片
    self.newsImg.image = [UIImage imageNamed:newsBatch.pic];
    CGRect imgRect = CGRectMake((kScreenSize.width-200)/2, kCellSpace, 200, 100);
    self.newsImg.frame = imgRect;
    // ** 2.设置内容
    self.newsExcerpt.text = newsBatch.excerpt;
    CGFloat eWidth  = kScreenSize.width - 2*kCellSpace;
    CGFloat eHeight = [ToolBox toolCalcHeightForString:newsBatch.excerpt Width:eWidth fontSize:10.0];
    CGRect eRect = CGRectMake(kCellSpace, kCellSpace+CGRectGetMaxY(self.newsImg.frame), eWidth, eHeight);
    self.newsExcerpt.frame = eRect;
    // ** 3.设置时间戳
    self.pubTime.text = [ToolBox toolGetDateFromString:newsBatch.publishtime];
    self.pubTime.frame = CGRectMake(kCellSpace, kCellSpace+CGRectGetMaxY(self.newsExcerpt.frame), 100, 15);
    // ** 4.设置数量
    self.newsCount.text = [NSString stringWithFormat:@"共%@条",newsBatch.count];
    self.newsCount.frame = CGRectMake(kScreenSize.width-kCellSpace-40, kCellSpace+CGRectGetMaxY(self.newsExcerpt.frame), 40, 15);
    // ** 5.设置左角标
    if ([newsBatch.name isEqualToString:@"recent"]) {
        self.badget.image = [UIImage imageNamed:@""];
    }else if ([newsBatch.name isEqualToString:@"yesterday"]) {
        self.badget.image = [UIImage imageNamed:@""];
    }else {
        self.badget.image = [UIImage imageNamed:@""];
    }
    self.badget.frame = CGRectMake(CGRectGetMaxX(_newsExcerpt.frame)-20, CGRectGetMinY(_newsExcerpt.frame), 20, 20);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
