//
//  AboutItemViewController.h
//  KanZH
//
//  Created by SW05 on 5/14/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutItemViewController : UIViewController
// ** 初始化构造方法
+ (instancetype)aboutItemWithIndex:(NSInteger)index;
- (instancetype)initItemWithIndex:(NSInteger)index;
@end
