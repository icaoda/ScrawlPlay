//
//  7PolorView.h
//  KanZH_Startpage
//
//  Created by SW05 on 5/7/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Polor7View : UIView
// ** 七星阵的数值字典
@property (nonatomic, strong) NSDictionary *rankData;
@end
