//
//  UsrDetailCell.h
//  KanZH
//
//  Created by SW05 on 5/18/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UsrDetailCell : UITableViewCell
// ** Set interface
- (void)showCellWithRect:(CGRect)rect name:(NSString *)aName scale:(id)aScale;
@end
