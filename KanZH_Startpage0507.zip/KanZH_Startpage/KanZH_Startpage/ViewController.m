//
//  ViewController.m
//  KanZH_Startpage
//
//  Created by SW05 on 5/4/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import "ViewController.h"
#import "TrendView.h"
#import "Polor7View.h"
#import "Header.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor blueColor];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"User" ofType:@"json"];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:[[NSData alloc] initWithContentsOfFile:path] options:NSJSONReadingAllowFragments error:nil];
    NSArray *trend = [dic objectForKey:@"trend"];
    NSMutableArray *dates = [NSMutableArray array];
    NSMutableArray *agrees = [NSMutableArray array];
    for (NSDictionary *dic in trend) {
        [dates addObject:dic[@"date"]];
        [agrees addObject:dic[@"agree"]];
    }
   
    
    
//    TrendView *view = [[TrendView alloc] initWithFrame:CGRectMake((kScreenSize.width-290)/2, 100, 290, 290)];
//    view.dateArray = dates;
//    view.scaleArray = agrees;
//    [self.view addSubview:view];
//    NSLog(@"view rect: %@",view);
    
    NSDictionary *stars = [dic objectForKey:@"star"];
    Polor7View *view = [[Polor7View alloc] initWithFrame:CGRectMake((kScreenSize.width-280)/2, 100, 280, 280)];
    view.rankData = stars;
    [self.view addSubview:view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
