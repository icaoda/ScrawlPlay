//
//  ToolBox.m
//  KanZH_Startpage
//
//  Created by SW05 on 5/4/16.
//  Copyright © 2016 SW05. All rights reserved.
//

#import "ToolBox.h"
#import <Availability.h>

@implementation ToolBox

+ (CGFloat)toolCalcHeightForString:(NSString *)str Width:(CGFloat)width fontSize:(CGFloat)size {
    CGSize cellSize = CGSizeMake(width, MAXFLOAT);
    NSDictionary *attr = @{NSFontAttributeName:[UIFont systemFontOfSize:size]};
    CGRect rect = [str boundingRectWithSize:cellSize options:NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingTruncatesLastVisibleLine attributes:attr context:nil];
    return rect.size.height;
}

+ (NSString *)toolGetDateFromString:(NSString *)str {
    return nil;
}

+ (NSString *)toolGetDateSubString:(NSString *)str {
    str = [str stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
    str = [str substringFromIndex:5];
    return str;
}
@end
