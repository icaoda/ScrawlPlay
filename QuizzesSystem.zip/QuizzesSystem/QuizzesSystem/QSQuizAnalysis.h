//
//  QSQuizAnalysis.h
//  TestSystem
//
//  Created by SW05 on 1/14/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// 数据模型，分析题数据类
@interface QSAnalysis : NSObject

@property (nonatomic, strong) NSString *score;

@property (nonatomic, strong) NSString *title;

@property (nonatomic, strong) NSString *answere;

@property (nonatomic, strong) NSString *comments;

@property (nonatomic, assign) CGFloat scoreGot;

- (instancetype)initWithScore:(NSString *)score title:(NSString *)title answer:(NSString *)answer;

@end

// 表单视图，分析题的视图容器
@interface QSQuizAnalysis : NSView

@property (weak) IBOutlet NSTextField *totalScore;

@property (unsafe_unretained) IBOutlet NSTextView *gotScore;

@property (unsafe_unretained) IBOutlet NSTextView *title;

@property (unsafe_unretained) IBOutlet NSTextView *answer;

@property (weak) IBOutlet NSButton *okBtn;

@property (unsafe_unretained) IBOutlet NSTextView *commentField;

- (void)setContents:(QSAnalysis *)analysis;

@end
