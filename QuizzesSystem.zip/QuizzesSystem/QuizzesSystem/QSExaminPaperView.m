//
//  QSExaminPaperView.m
//  TestSystem
//
//  Created by SW05 on 3/7/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import "QSExaminPaperView.h"
#import "QSMysql.h"

#import "QSQueryTableJudge.h"
#import "QSQueryTableSingle.h"
#import "QSQueryTableMultiple.h"
#import "QSQueryTableAnalysis.h"

@interface QSExaminPaperView ()

@property (nonatomic, weak) IBOutlet NSTextField *timeLbl;
@property (nonatomic, weak) IBOutlet NSTextField *deptLbl;
@property (nonatomic, weak) IBOutlet NSTextField *usNmLbl;
@property (nonatomic, weak) IBOutlet NSTextField *scorLbl;

@property (nonatomic, weak) IBOutlet NSTextField *judgLbl;
@property (nonatomic, weak) IBOutlet NSTextField *singLbl;
@property (nonatomic, weak) IBOutlet NSTextField *multLbl;
@property (nonatomic, weak) IBOutlet NSTextField *anlyLbl;

@property (nonatomic, strong) IBOutlet QSQueryTableJudge *judgTable;
@property (nonatomic, strong) IBOutlet QSQueryTableSingle *singTable;
@property (nonatomic, strong) IBOutlet QSQueryTableMultiple *multTable;
@property (nonatomic, strong) IBOutlet QSQueryTableAnalysis *anlyTable;

@property (nonatomic, strong) QSMysql *mysql;
@property (nonatomic, strong) NSString *key;

@end

@implementation QSExaminPaperView

// load data from Tester Record
- (void)loadDataFromServer:(NSString *)timeStamp mySQL:(QSMysql *)mysql {
    self.key   = timeStamp;
    self.mysql = mysql;
    
    [self configurateUI];
    [self configurateTable];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

// configuration UI elements
- (void)configurateUI {
    
    NSString *sheetNm = @"Test_Record_All";
    NSString *rowKey  = [NSString stringWithFormat:@"timeStmp='%@'",self.key];
    
    NSString *departme = [self.mysql queryColumn:@"departme" rowKey:rowKey inSheet:sheetNm];
    NSString *userName = [self.mysql queryColumn:@"userName" rowKey:rowKey inSheet:sheetNm];
    [self.deptLbl setStringValue:departme];
    [self.usNmLbl setStringValue:userName];
    
    NSString *timeRefe = [self.mysql queryColumn:@"timeRefe" rowKey:rowKey inSheet:sheetNm];
    NSString *timeCost = [self.mysql queryColumn:@"timeCost" rowKey:rowKey inSheet:sheetNm];
    [self.timeLbl setStringValue:[NSString stringWithFormat:@"%@/%@'",timeCost,timeRefe]];
    
    NSString *scoreTot = [self.mysql queryColumn:@"scoreTot" rowKey:rowKey inSheet:sheetNm];
    NSString *scoreGot = [self.mysql queryColumn:@"scoreGot" rowKey:rowKey inSheet:sheetNm];
    [self.scorLbl setStringValue:[NSString stringWithFormat:@"%@/%@'",scoreGot,scoreTot]];
    
    NSString *judgeQty = [self.mysql queryColumn:@"judgeQty" rowKey:rowKey inSheet:sheetNm];
    NSString *judgeSco = [self.mysql queryColumn:@"judgeSco" rowKey:rowKey inSheet:sheetNm];
    NSString *titleLb1 = [NSString stringWithFormat:@"1.True or False(total %@ quiz(es), %@' per quiz).",judgeQty,judgeSco];
    [self.judgLbl setStringValue:titleLb1];
    
    NSString *singlQty = [self.mysql queryColumn:@"singlQty" rowKey:rowKey inSheet:sheetNm];
    NSString *singlSco = [self.mysql queryColumn:@"singlSco" rowKey:rowKey inSheet:sheetNm];
    NSString *titleLb2 = [NSString stringWithFormat:@"2.Single selection(total %@ quiz(es), %@' per quiz).",singlQty,singlSco];
    [self.singLbl setStringValue:titleLb2];
    
    NSString *multiQty = [self.mysql queryColumn:@"multiQty" rowKey:rowKey inSheet:sheetNm];
    NSString *multiSco = [self.mysql queryColumn:@"multiSco" rowKey:rowKey inSheet:sheetNm];
    NSString *titleLb3 = [NSString stringWithFormat:@"3.Multiple selections(total %@ quiz(es), %@' per quiz).",multiQty,multiSco];
    [self.multLbl setStringValue:titleLb3];
    
    NSString *analyQty = [self.mysql queryColumn:@"analyQty" rowKey:rowKey inSheet:sheetNm];
    NSString *analySco = [self.mysql queryColumn:@"analySco" rowKey:rowKey inSheet:sheetNm];
    NSString *titleLb4 = [NSString stringWithFormat:@"4.Analysis(total %@ quiz(es), %@' per quiz).",analyQty,analySco];
    [self.anlyLbl setStringValue:titleLb4];
}

// configuration tables
- (void)configurateTable {
    
    [self.judgTable prepareData:self.key mySQL:self.mysql];
    [self.judgTable setDataSource:self.judgTable];
    [self.judgTable setDelegate:self.judgTable];
    
    [self.singTable prepareData:self.key mySQL:self.mysql];
    [self.singTable setDataSource:self.singTable];
    [self.singTable setDelegate:self.singTable];
    
    [self.multTable prepareData:self.key mySQL:self.mysql];
    [self.multTable setDataSource:self.multTable];
    [self.multTable setDelegate:self.multTable];
    
    [self.anlyTable prepareData:self.key mySQL:self.mysql];
    [self.anlyTable setDataSource:self.anlyTable];
    [self.anlyTable setDelegate:self.anlyTable];
}

@end
