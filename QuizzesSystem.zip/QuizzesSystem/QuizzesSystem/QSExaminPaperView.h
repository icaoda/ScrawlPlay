//
//  QSExaminPaperView.h
//  TestSystem
//
//  Created by SW05 on 3/7/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class QSMysql;

@interface QSExaminPaperView : NSView

// load data from Tester Record
- (void)loadDataFromServer:(NSString *)timeStamp mySQL:(QSMysql *)mysql;

@end
