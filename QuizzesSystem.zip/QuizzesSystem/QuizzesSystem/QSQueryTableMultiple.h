//
//  QSQueryTableMultiple.h
//  TestSystem
//
//  Created by SW05 on 3/7/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class QSMysql;

@interface QSQueryTableMultiple : NSTableView <NSTableViewDataSource, NSTableViewDelegate>

- (void)prepareData:(NSString *)key mySQL:(QSMysql *)mysql;

@end
