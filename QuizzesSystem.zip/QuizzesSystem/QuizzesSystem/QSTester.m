//
//  QSTester.m
//  QuizzesSystem
//
//  Created by SW05 on 12/7/15.
//  Copyright © 2015 TDE-SMTFA05. All rights reserved.
//

#import "QSTester.h"
#import "QSQuestion.h"

@implementation QSTester

- (instancetype)initWithUserID:(NSString *)userID password:(NSString *)pw {
    if (self = [super initWithUserID:userID password:pw]) {
        NSLog(@"user login");
        self.isLogin = NO;
    }
    return self;
}

- (BOOL)login {
    
    NSString *queryKey = [NSString stringWithFormat:@"user='%@'",self.userID];
    NSArray *result = [self.mysql queryWithKey:queryKey inSheet:@"Testers"];
    if (result != NULL && result[2] == self.password) {NSLog(@"%@ - login ok!",self);
        
        // 查询结果赋值给测试者
        self.isLogin = YES;
        self.testerName = result[3];
        self.department = result[4];
        
    } else {
        NSLog(@"%@ - login failed!",self);
        self.isLogin = NO;
    }
    return self.isLogin;
}

- (void)setPaperWithSettings:(NSArray *)setting {
    
    self.paper = [[QSPaper alloc] init];
    [self.paper setPaperWithSettings:setting];NSLog(@"[%@]-pass here",self);
}

- (void)generaterPaper {
    
    [self.paper generatorPaperWithMysql:self.mysql forDepart:self.department];
    NSLog(@"%@ - paper generated!",self);
    
}

- (NSString *)combineStringWithPrefix0:(NSUInteger)num {
    if (num > 10) {
        return [NSString stringWithFormat:@"%lu",num];
    } else {
        return [NSString stringWithFormat:@"0%lu",num];
    }
}

- (BOOL)puddingTestRecordToServer {
    
    BOOL puddingOK = YES;NSLog(@"puok - init -%hhd-",puddingOK);
    // 1.上传数据，Tester_Record表格：添加考试记录
    NSDateComponents *dateComp = [[NSCalendar currentCalendar] components:(NSCalendarUnitYear|NSCalendarUnitMonth|
                                                                           NSCalendarUnitDay|NSCalendarUnitHour|
                                                                           NSCalendarUnitMinute|NSCalendarUnitSecond)
                                                                 fromDate:[NSDate date]];
    NSString *timeStamp = [NSString stringWithFormat:@"%@%@%@%@%@%@",
                           [self combineStringWithPrefix0:dateComp.year],
                           [self combineStringWithPrefix0:dateComp.month],
                           [self combineStringWithPrefix0:dateComp.day],
                           [self combineStringWithPrefix0:dateComp.hour],
                           [self combineStringWithPrefix0:dateComp.minute],
                           [self combineStringWithPrefix0:dateComp.second]];
    NSArray *contents = @[ self.userID, self.testerName,
                           [NSString stringWithFormat:@"%lu",self.paper.settings.time],
                           [NSString stringWithFormat:@"%lu",self.paper.userRank.time],
                           [NSString stringWithFormat:@"%lu",[self.paper.settings totalScore]],
                           [NSString stringWithFormat:@"%lu",[self.paper calculateAnswersAndReturnScoreSum]],
                           timeStamp, @"Y", @"0"];
    if ([self.mysql insertRow:contents forTable:@"Testers_Record"]==NO) {
        puddingOK = NO;
    }
    
    // 2.上传数据，Testers表格：修改unread列
    NSString *key = [NSString stringWithFormat:@"user='%@'",self.userID];
    NSArray *rowInTesters = [self.mysql queryWithKey:key inSheet:@"Testers"];
    NSString *content = [NSString stringWithFormat:@"unread='%lu'",[rowInTesters[5] integerValue]+1];
    if ([self.mysql updateContents:content withKey:key inSheet:@"Testers"]==NO) {
        puddingOK = NO;
    }NSLog(@"puok - post testers -%hhd-",puddingOK);
    
    // 3.上传数据，Administrator_Config表格：修改unread列
    key = [NSString stringWithFormat:@"department='%@'",rowInTesters[4]];
    NSArray *rowInAdminC = [self.mysql queryWithKey:key inSheet:@"Administrators_Configuration"];
    content = [NSString stringWithFormat:@"unread='%lu'",[rowInAdminC[10] integerValue]+1];
    if ([self.mysql updateContents:content withKey:key inSheet:@"Administrators_Configuration"]==NO) {
        puddingOK = NO;
    }NSLog(@"puok - post config -%hhd-",puddingOK);
    
    // 4.上传数据，UserID_TimeStamp表格：添加表格
    NSString *tableName = [NSString stringWithFormat:@"%@_%@",self.userID,timeStamp];
    if ([self.mysql createAnalysisRecordTable:tableName]==NO) {
        puddingOK = NO;
    }NSLog(@"puok - post create analy -%hhd-",puddingOK);
    
    for (QSQuestionAnalysis *analy in self.paper.analysisQuestions) {
        contents = @[[NSString stringWithFormat:@"%lu",self.paper.settings.analysisScore],
                     analy.title, analy.userAnswer ];
        if ([self.mysql insertRow:contents intoAnalysisRecord:tableName]==NO) {
            puddingOK = NO;
        }NSLog(@"puok - post insert anal -%hhd-",puddingOK);
    }
    
    // 5.上传数据，Test_Record_All表格：添加行记录
    // 5.1 设置数据字串
    NSString *settgContents = [NSString stringWithFormat:@"'%@','%@','%@','%lu','%lu','%lu','%lu','%lu','%lu','%lu','%lu','%lu','%lu','%lu','%lu',", tableName,
                               self.department,                     self.testerName,
                               self.paper.settings.time,            self.paper.userRank.time,
                               [self.paper.settings totalScore],    [self.paper calculateAnswersAndReturnScoreSum],
                               self.paper.settings.judgeCount,      self.paper.settings.judgeScore,
                               self.paper.settings.singleCount,     self.paper.settings.singleScore,
                               self.paper.settings.multipleCount,   self.paper.settings.multipleScore,
                               self.paper.settings.analysisCount,   self.paper.settings.analysisScore ];
    // 5.2 判断题数据字串
    NSString *judgeContents = [NSString stringWithFormat:@""];
    NSUInteger qtyOfJudge   = [self.paper.judgeQuestions count];
    for (int i=0; i<10; i++) {
        NSString *quizCont = @"";
        if (i >= qtyOfJudge) {
            quizCont = [quizCont stringByAppendingString:@"'','','',"];
        } else {
            QSQuestion *quiz = [self.paper.judgeQuestions objectAtIndex:i];
            quizCont = [quizCont stringByAppendingFormat:@"'%@','%@','%@',",
                        quiz.title,quiz.answer,quiz.userAnswer];
        }
        judgeContents = [judgeContents stringByAppendingString:quizCont];
    }NSLog(@"create string [-]%@[-] ok",judgeContents);
    // 5.3 单选题数据字串
    NSString *singlContents = [NSString stringWithFormat:@""];
    NSUInteger qtySingle    = [self.paper.singleQuestions count];
    for (int i=0; i<10; i++) {
        NSString *quizCont = @"";
        if (i >= qtySingle) {
            quizCont = [quizCont stringByAppendingString:@"'','','','','','','',"];
        } else {
            QSQuestionSelect *quiz = [self.paper.singleQuestions objectAtIndex:i];
            quizCont = [quizCont stringByAppendingFormat:@"'%@','%@','%@','%@','%@','%@','%@',",
                       quiz.title,quiz.answer,quiz.userAnswer,
                       quiz.options[0],quiz.options[1],quiz.options[2],quiz.options[3]];
        }
        singlContents = [singlContents stringByAppendingString:quizCont];
    }NSLog(@"create string [-]%@[-] ok",singlContents);
    // 5.4 多选题数据字串
    NSString *multiContents = [NSString stringWithFormat:@""];
    NSUInteger qtyMulti     = [self.paper.multipleQuestions count];
    for (int i=0; i<10; i++) {
        NSString *quizCont = @"";
        if (i >= qtyMulti) {
            quizCont = [quizCont stringByAppendingString:@"'','','','','','','',"];
        } else {
            QSQuestionSelect *quiz = [self.paper.multipleQuestions objectAtIndex:i];
            quizCont = [quizCont stringByAppendingFormat:@"'%@','%@','%@','%@','%@','%@','%@',",
                        quiz.title,quiz.answer,quiz.userAnswer,
                        quiz.options[0],quiz.options[1],quiz.options[2],quiz.options[3]];
        }
        multiContents = [multiContents stringByAppendingString:quizCont];
    }NSLog(@"create string [-]%@[-] ok",multiContents);
    // 5.5 分析题数据字串
    NSString *analyContents = [NSString stringWithFormat:@""];
    NSUInteger qtyAnalysis  = [self.paper.analysisQuestions count];
    for (int i=0; i<10; i++) {
        NSString *quizCont = @"";
        if (i >= qtyAnalysis) {
            quizCont = [quizCont stringByAppendingString:@"'','','','',"];
        } else {
            QSQuestionAnalysis *quiz = [self.paper.analysisQuestions objectAtIndex:i];
            quizCont = [quizCont stringByAppendingFormat:@"'%@','%@','','',",
                        quiz.title,quiz.userAnswer];
        }
        analyContents = [analyContents stringByAppendingString:quizCont];
    }
    analyContents = [analyContents substringToIndex:[analyContents length]-1];NSLog(@"create string [-]%@[-] ok",analyContents);
    
    // 5.6 准备参数，调用sql接口
    contents = @[settgContents, judgeContents, singlContents, multiContents, analyContents];
    tableName = @"Test_Record_All";
    if ([self.mysql insertRow:contents intoAllPaperRecord:tableName] == NO) {
        puddingOK = NO;
    }NSLog(@"Pudding paper record to %@ ok!",tableName);
    
    return puddingOK;
}

@end
