//
//  QSQueryTableJudge.m
//  TestSystem
//
//  Created by SW05 on 3/7/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import "QSQueryTableJudge.h"
#import "QSJudgeCell.h"
#import "QSMysql.h"

@interface QSQueryTableJudge ()

@property (nonatomic, strong) NSMutableArray  *dataModel;
@property (nonatomic, strong) QSMysql  *mysql;
@property (nonatomic, strong) NSString *key;

@end

@implementation QSQueryTableJudge

- (void)prepareData:(NSString *)key mySQL:(QSMysql *)mysql {
    
    self.mysql = mysql;
    self.key   = key;
    
    [self compositeDataModel];
    
}

- (void)compositeDataModel {
    
    self.dataModel = [NSMutableArray array];
    
    for (int i=0; i<10; i++) {
        
        NSString *sheetNm = @"Test_Record_All";
        NSString *rowKey  = [NSString stringWithFormat:@"timeStmp='%@'",self.key];
        
        NSString *colKeyT = [NSString stringWithFormat:@"judgTtl%d",i];
        NSString *judgTtl = [self.mysql queryColumn:colKeyT rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyA = [NSString stringWithFormat:@"judgAns%d",i];
        NSString *judgAns = [self.mysql queryColumn:colKeyA rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyU = [NSString stringWithFormat:@"judgUAn%d",i];
        NSString *judgUAn = [self.mysql queryColumn:colKeyU rowKey:rowKey inSheet:sheetNm];
        
        if ([judgTtl isEqualToString:@""] == YES) {
            break;
        }
        
        NSArray *quiz = @[judgTtl, judgAns, judgUAn];
        [self.dataModel addObject:quiz];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

#pragma mark - DataSource method
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return [self.dataModel count];
}

#pragma mark - Delegate method
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    
    // 1.Retrive cellView form nib
    NSArray *nibs = [[NSArray alloc] init];
    QSJudgeCell *cell;
    [[NSBundle mainBundle] loadNibNamed:@"QSTestViewController" owner:nil topLevelObjects:&nibs];
    
    for (id nib in nibs) {
        if ([nib isMemberOfClass:[QSJudgeCell class]] == YES) {
            cell = nib;
        }
    }
    
    // 2.Config the cell
    NSArray *quiz = [self.dataModel objectAtIndex:row];
    [cell.title setStringValue:quiz[0]];
    
    // set refer answer
    if ([quiz[1] isEqualToString:@"T"] == YES) {
        
        [cell.ansLbl setStringValue:@"YES"];
        
    } else {
        [cell.ansLbl setStringValue:@"NO"];
    }
    
    // set user choice
    if ([quiz[2] isEqualToString:@"T"] == YES) {
        
        [cell.yesBtn setState:NSOnState];
        
    } else {
        
        [cell.noBtn setState:NSOnState];
    }
    
    // disable buttons
    [cell.yesBtn setEnabled:NO];
    [cell.noBtn  setEnabled:NO];
    return cell;
}

#pragma mark - table view Delegate method
- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row {
    return NO;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 200.0;
}

@end
