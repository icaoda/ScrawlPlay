//
//  QSMasterViewController.h
//  TestSystem
//
//  Created by SW05 on 3/14/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QSMasterViewController : NSViewController

@end
