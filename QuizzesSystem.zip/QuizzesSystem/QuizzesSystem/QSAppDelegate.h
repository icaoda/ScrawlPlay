//
//  AppDelegate.h
//  QuizzesSystem
//
//  Created by SW05 on 12/5/15.
//  Copyright © 2015 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QSAppDelegate : NSObject <NSApplicationDelegate>


@end

/*
 
 
 CREATE table Test_Record_All(
        id int unsigned not null auto_increment,
        timeStmp varchar(50) not null,
        departme varchar(50) not null,
        userName varchar(50) not null,
        timeRefe varchar(50) not null,
        timeCost varchar(50) not null,
        scoreTot varchar(50) not null,
        scoreGot varchar(50) not null,
        judgeQty varchar(50) not null,
        judgeSco varchar(50) not null,
        singlQty varchar(50) not null,
        singlSco varchar(50) not null,
        multiQty varchar(50) not null,
        multiSco varchar(50) not null,
        analyQty varchar(50) not null,
        analySco varchar(50) not null,
        judgTtl0 varchar(100), judgAns0 varchar(5), judgUAn0 varchar(5),
        judgTtl1 varchar(100), judgAns1 varchar(5), judgUAn1 varchar(5),
        judgTtl2 varchar(100), judgAns2 varchar(5), judgUAn2 varchar(5),
        judgTtl3 varchar(100), judgAns3 varchar(5), judgUAn3 varchar(5),
        judgTtl4 varchar(100), judgAns4 varchar(5), judgUAn4 varchar(5),
        judgTtl5 varchar(100), judgAns5 varchar(5), judgUAn5 varchar(5),
        judgTtl6 varchar(100), judgAns6 varchar(5), judgUAn6 varchar(5),
        judgTtl7 varchar(100), judgAns7 varchar(5), judgUAn7 varchar(5),
        judgTtl8 varchar(100), judgAns8 varchar(5), judgUAn8 varchar(5),
        judgTtl9 varchar(100), judgAns9 varchar(5), judgUAn9 varchar(5),
        singTtl0 varchar(100), singAns0 varchar(5), singUan0 varchar(5), singOpa0 varchar(100), singOpb0 varchar(100), singOpc0 varchar(100),singOpd0 varchar(100),
        singTtl1 varchar(100), singAns1 varchar(5), singUan1 varchar(5), singOpa1 varchar(100), singOpb1 varchar(100), singOpc1 varchar(100),singOpd1 varchar(100),
        singTtl2 varchar(100), singAns2 varchar(5), singUan2 varchar(5), singOpa2 varchar(100), singOpb2 varchar(100), singOpc2 varchar(100),singOpd2 varchar(100),
        singTtl3 varchar(100), singAns3 varchar(5), singUan3 varchar(5), singOpa3 varchar(100), singOpb3 varchar(100), singOpc3 varchar(100),singOpd3 varchar(100),
        singTtl4 varchar(100), singAns4 varchar(5), singUan4 varchar(5), singOpa4 varchar(100), singOpb4 varchar(100), singOpc4 varchar(100),singOpd4 varchar(100),
        singTtl5 varchar(100), singAns5 varchar(5), singUan5 varchar(5), singOpa5 varchar(100), singOpb5 varchar(100), singOpc5 varchar(100),singOpd5 varchar(100),
        singTtl6 varchar(100), singAns6 varchar(5), singUan6 varchar(5), singOpa6 varchar(100), singOpb6 varchar(100), singOpc6 varchar(100),singOpd6 varchar(100),
        singTtl7 varchar(100), singAns7 varchar(5), singUan7 varchar(5), singOpa7 varchar(100), singOpb7 varchar(100), singOpc7 varchar(100),singOpd7 varchar(100),
        singTtl8 varchar(100), singAns8 varchar(5), singUan8 varchar(5), singOpa8 varchar(100), singOpb8 varchar(100), singOpc8 varchar(100),singOpd8 varchar(100),
        singTtl9 varchar(100), singAns9 varchar(5), singUan9 varchar(5), singOpa9 varchar(100), singOpb9 varchar(100), singOpc9 varchar(100),singOpd9 varchar(100),
        multTtl0 varchar(100), multAns0 varchar(5), multUan0 varchar(5), multOpa0 varchar(100), multOpb0 varchar(100), multOpc0 varchar(100),multOpd0 varchar(100),
        multTtl1 varchar(100), multAns1 varchar(5), multUan1 varchar(5), multOpa1 varchar(100), multOpb1 varchar(100), multOpc1 varchar(100),multOpd1 varchar(100),
        multTtl2 varchar(100), multAns2 varchar(5), multUan2 varchar(5), multOpa2 varchar(100), multOpb2 varchar(100), multOpc2 varchar(100),multOpd2 varchar(100),
        multTtl3 varchar(100), multAns3 varchar(5), multUan3 varchar(5), multOpa3 varchar(100), multOpb3 varchar(100), multOpc3 varchar(100),multOpd3 varchar(100),
        multTtl4 varchar(100), multAns4 varchar(5), multUan4 varchar(5), multOpa4 varchar(100), multOpb4 varchar(100), multOpc4 varchar(100),multOpd4 varchar(100),
        multTtl5 varchar(100), multAns5 varchar(5), multUan5 varchar(5), multOpa5 varchar(100), multOpb5 varchar(100), multOpc5 varchar(100),multOpd5 varchar(100),
        multTtl6 varchar(100), multAns6 varchar(5), multUan6 varchar(5), multOpa6 varchar(100), multOpb6 varchar(100), multOpc6 varchar(100),multOpd6 varchar(100),
        multTtl7 varchar(100), multAns7 varchar(5), multUan7 varchar(5), multOpa7 varchar(100), multOpb7 varchar(100), multOpc7 varchar(100),multOpd7 varchar(100),
        multTtl8 varchar(100), multAns8 varchar(5), multUan8 varchar(5), multOpa8 varchar(100), multOpb8 varchar(100), multOpc8 varchar(100),multOpd8 varchar(100),
        multTtl9 varchar(100), multAns9 varchar(5), multUan9 varchar(5), multOpa9 varchar(100), multOpb9 varchar(100), multOpc9 varchar(100),multOpd9 varchar(100),
        analTtl0 varchar(100), analAns0 varchar(100), analCom0 varchar(100), analSco0 varchar(10),
        analTtl1 varchar(100), analAns1 varchar(100), analCom1 varchar(100), analSco1 varchar(10),
        analTtl2 varchar(100), analAns2 varchar(100), analCom2 varchar(100), analSco2 varchar(10),
        analTtl3 varchar(100), analAns3 varchar(100), analCom3 varchar(100), analSco3 varchar(10),
        analTtl4 varchar(100), analAns4 varchar(100), analCom4 varchar(100), analSco4 varchar(10),
        analTtl5 varchar(100), analAns5 varchar(100), analCom5 varchar(100), analSco5 varchar(10),
        analTtl6 varchar(100), analAns6 varchar(100), analCom6 varchar(100), analSco6 varchar(10),
        analTtl7 varchar(100), analAns7 varchar(100), analCom7 varchar(100), analSco7 varchar(10),
        analTtl8 varchar(100), analAns8 varchar(100), analCom8 varchar(100), analSco8 varchar(10),
        analTtl9 varchar(100), analAns9 varchar(100), analCom9 varchar(100), analSco9 varchar(10),
        primary key(id)
 );
 */
/*
insert into Test_Record_All (
id,
timeStmp,
departme,
userName,
timeRefe,
timeCost,
scoreTot,
scoreGot,
judgeQty,
judgeSco,
singlQty,
singlSco,
multiQty,
multiSco,
analyQty,
analySco,
judgTtl0, judgAns0, judgUAn0,
judgTtl1, judgAns1, judgUAn1,
judgTtl2, judgAns2, judgUAn2,
judgTtl3, judgAns3, judgUAn3,
judgTtl4, judgAns4, judgUAn4,
judgTtl5, judgAns5, judgUAn5,
judgTtl6, judgAns6, judgUAn6,
judgTtl7, judgAns7, judgUAn7,
judgTtl8, judgAns8, judgUAn8,
judgTtl9, judgAns9, judgUAn9,
singTtl0 , singAns0 , singUan0 , singOpa0 , singOpb0 , singOpc0 ,singOpd0 ,
singTtl1 , singAns1 , singUan1 , singOpa1 , singOpb1 , singOpc1 ,singOpd1 ,
singTtl2 , singAns2 , singUan2 , singOpa2 , singOpb2 , singOpc2 ,singOpd2 ,
singTtl3 , singAns3 , singUan3 , singOpa3 , singOpb3 , singOpc3 ,singOpd3 ,
singTtl4 , singAns4 , singUan4 , singOpa4 , singOpb4 , singOpc4 ,singOpd4 ,
singTtl5 , singAns5 , singUan5 , singOpa5 , singOpb5 , singOpc5 ,singOpd5 ,
singTtl6 , singAns6 , singUan6 , singOpa6 , singOpb6 , singOpc6 ,singOpd6 ,
singTtl7 , singAns7 , singUan7 , singOpa7 , singOpb7 , singOpc7 ,singOpd7 ,
singTtl8 , singAns8 , singUan8 , singOpa8 , singOpb8 , singOpc8 ,singOpd8 ,
singTtl9 , singAns9 , singUan9 , singOpa9 , singOpb9 , singOpc9 ,singOpd9 ,
multTtl0 , multAns0 , multUan0 , multOpa0 , multOpb0 , multOpc0 ,multOpd0 ,
multTtl1 , multAns1 , multUan1 , multOpa1 , multOpb1 , multOpc1 ,multOpd1 ,
multTtl2 , multAns2 , multUan2 , multOpa2 , multOpb2 , multOpc2 ,multOpd2 ,
multTtl3 , multAns3 , multUan3 , multOpa3 , multOpb3 , multOpc3 ,multOpd3 ,
multTtl4 , multAns4 , multUan4 , multOpa4 , multOpb4 , multOpc4 ,multOpd4 ,
multTtl5 , multAns5 , multUan5 , multOpa5 , multOpb5 , multOpc5 ,multOpd5 ,
multTtl6 , multAns6 , multUan6 , multOpa6 , multOpb6 , multOpc6 ,multOpd6 ,
multTtl7 , multAns7 , multUan7 , multOpa7 , multOpb7 , multOpc7 ,multOpd7 ,
multTtl8 , multAns8 , multUan8 , multOpa8 , multOpb8 , multOpc8 ,multOpd8 ,
multTtl9 , multAns9 , multUan9 , multOpa9 , multOpb9 , multOpc9 ,multOpd9 ,
analTtl0 , analAns0 , analCom0 , analSco0 ,
analTtl1 , analAns1 , analCom1 , analSco1 ,
analTtl2 , analAns2 , analCom2 , analSco2 ,
analTtl3 , analAns3 , analCom3 , analSco3 ,
analTtl4 , analAns4 , analCom4 , analSco4 ,
analTtl5 , analAns5 , analCom5 , analSco5 ,
analTtl6 , analAns6 , analCom6 , analSco6 ,
analTtl7 , analAns7 , analCom7 , analSco7 ,
analTtl8 , analAns8 , analCom8 , analSco8 ,
analTtl9 , analAns9 , analCom9 , analSco9 )
values(
0,
'F7684885_20150101120025',
'PSD_NPI',
'Simon',
'120','78',
'100','98',
'5','6',
'7','8',
'3','4',
'6','5',
't0','j0','F',
't1','j1','T',
'','','',
'','','',
'','','',
'','','',
'','','',
'','','',
'','','',
'','','',
's1','ds','ds','dsf','dsfds','dsfds','dfs',
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
'm1','ms','ms','msf','msfds','msfds','mfs',
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
''  ,''  ,''  ,''   ,''     ,''     ,''   ,
'analy0','dsfds','dsfds','dsfds',
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     ,
''     ,''     ,''     ,''     , 
''     ,''     ,''     ,''
);
 
 */







/*
update Test_Record_All set
analCom0='comments' , analSco0='5'
where id=1;
 
 */

/*
select * from Test_Record_All where id=1;
 */









