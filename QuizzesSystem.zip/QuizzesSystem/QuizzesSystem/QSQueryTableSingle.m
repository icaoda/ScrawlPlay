//
//  QSQueryTableSingle.m
//  TestSystem
//
//  Created by SW05 on 3/7/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import "QSQueryTableSingle.h"
#import "QSSingleCell.h"
#import "QSMysql.h"

@interface QSQueryTableSingle ()

@property (nonatomic, strong) NSMutableArray  *dataModel;
@property (nonatomic, strong) QSMysql  *mysql;
@property (nonatomic, strong) NSString *key;

@end

@implementation QSQueryTableSingle

- (void)prepareData:(NSString *)key mySQL:(QSMysql *)mysql {
    
    self.mysql = mysql;
    self.key   = key;
    
    [self compositeDataModel];
    
}

- (void)compositeDataModel {
    
    self.dataModel = [NSMutableArray array];
    
    for (int i=0; i<10; i++) {
        
        NSString *sheetNm = @"Test_Record_All";
        NSString *rowKey  = [NSString stringWithFormat:@"timeStmp='%@'",self.key];
        
        NSString *colKeyT = [NSString stringWithFormat:@"singTtl%d",i];
        NSString *singTtl = [self.mysql queryColumn:colKeyT rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyA = [NSString stringWithFormat:@"singAns%d",i];
        NSString *singAns = [self.mysql queryColumn:colKeyA rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyU = [NSString stringWithFormat:@"singUan%d",i];
        NSString *singUAn = [self.mysql queryColumn:colKeyU rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeya = [NSString stringWithFormat:@"singOpa%d",i];
        NSString *singOpa = [self.mysql queryColumn:colKeya rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyb = [NSString stringWithFormat:@"singOpb%d",i];
        NSString *singOpb = [self.mysql queryColumn:colKeyb rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyc = [NSString stringWithFormat:@"singOpc%d",i];
        NSString *singOpc = [self.mysql queryColumn:colKeyc rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyd = [NSString stringWithFormat:@"singOpd%d",i];
        NSString *singOpd = [self.mysql queryColumn:colKeyd rowKey:rowKey inSheet:sheetNm];
        
        if ([singTtl isEqualToString:@""] == YES) {
            break;
        }
        
        NSArray *quiz = @[singTtl, singAns, singUAn, singOpa, singOpb, singOpc, singOpd];
        [self.dataModel addObject:quiz];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}


#pragma mark - DataSource method
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return [self.dataModel count];
}

#pragma mark - Delegate method
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    
    // 1.Retrive cellView form nib
    NSArray *nibs = [[NSArray alloc] init];
    QSSingleCell *cell;
    [[NSBundle mainBundle] loadNibNamed:@"QSTestViewController" owner:nil topLevelObjects:&nibs];
    
    for (id nib in nibs) {
        if ([nib isMemberOfClass:[QSSingleCell class]] == YES) {
            cell = nib;
        }
    }
    
    // 2.Config the cell
    NSArray *quiz = [self.dataModel objectAtIndex:row];
    [cell.title setStringValue:quiz[0]];
    
    // set refer answer
    [cell.ansLbl setStringValue:quiz[1]];
    
    // set user choice
    if ([quiz[2] isEqualToString:@"A"] == YES) {
        [cell.aBtn setState:NSOnState];
    }
    
    if ([quiz[2] isEqualToString:@"B"] == YES) {
        [cell.bBtn setState:NSOnState];
    }
    
    if ([quiz[2] isEqualToString:@"C"] == YES) {
        [cell.cBtn setState:NSOnState];
    }
    
    if ([quiz[2] isEqualToString:@"D"] == YES) {
        [cell.dBtn setState:NSOnState];
    }
    
    // set option title
    [cell.aBtn setTitle:quiz[3]];
    [cell.bBtn setTitle:quiz[4]];
    [cell.cBtn setTitle:quiz[5]];
    [cell.dBtn setTitle:quiz[6]];
    
    // disable buttons
    [cell.aBtn setEnabled:NO];
    [cell.bBtn setEnabled:NO];
    [cell.cBtn setEnabled:NO];
    [cell.dBtn setEnabled:NO];
    
    return cell;
}

#pragma mark - table view Delegate method
- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row {
    return NO;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 200.0;
}

@end
