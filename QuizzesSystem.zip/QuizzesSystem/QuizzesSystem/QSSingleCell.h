//
//  QSSingleCell.h
//  TestSystem
//
//  Created by SW05 on 1/19/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "QSQuestion.h"

@interface QSSingleCell : NSView

@property (weak) IBOutlet NSTextField *title;

@property (weak) IBOutlet NSButton *aBtn;
@property (weak) IBOutlet NSButton *bBtn;
@property (weak) IBOutlet NSButton *cBtn;
@property (weak) IBOutlet NSButton *dBtn;
@property (weak) IBOutlet NSTextField *ansLbl;

- (void)setContentsOfCell:(QSQuestionSelect *)question;

@end
