//
//  QSMasterViewController.m
//  TestSystem
//
//  Created by SW05 on 3/14/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import "QSMasterViewController.h"
#import "QSLeftViewController.h"
#import "QSRightViewController.h"
#import "QSMiddlePanel.h"
#import "Constants.h"

#import "QSUser.h"
#import "QSTester.h"
#import "QSAdministrator.h"

#import "QSTools.h"

@interface QSMasterViewController ()

@property (nonatomic, strong) QSUser *user;

@property (nonatomic, assign) BOOL isCurrentUserAdmn;

@property (nonatomic, strong) NSMutableArray *viewControllers;

@end


@implementation QSMasterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    
    // Do any additional setup after loading the view.
    NSLog(@"hahah%@",self.viewControllers);
    self.viewControllers = [NSMutableArray array];
    
    // 添加左侧视图控制器：用户切换面板
    QSLeftViewController *lvc = [[QSLeftViewController alloc] initWithNibName:@"QSLeftViewController" bundle:nil];
    [lvc.view setFrame:CGRectMake(0, 0, 80, 600)];
    [self.viewControllers addObject:lvc];
    [self.view addSubview:lvc.view];
    
    // 添加中间视图控制器：登陆界面
    QSLoginViewController *mvc = [[QSLoginViewController alloc] initWithNibName:@"QSLoginViewController" bundle:nil];
    [mvc.view setFrame:CGRectMake(81, 0, 718, 600)];
    [self.viewControllers addObject:mvc];
    [self.view addSubview:mvc.view];
    
    // 添加右侧视图控制器：功能切换面板
    QSRightViewController *rmv = [[QSRightViewController alloc] initWithNibName:@"QSRightViewController" bundle:nil];
    [rmv setUser:self.user];
    [rmv.view setFrame:CGRectMake(800, 0, 160, 600)];
    [self.viewControllers addObject:rmv];
    [self.view addSubview:rmv.view];
    
    // 注册通知中心：监测系统通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recieveLeftPanelAction:)
                                                 name:NSNotificationLeftPanel object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recieveRightPanelAction:)
                                                 name:NSNotificationRightPanel object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(initializingUsers:)
                                                 name:NSNotificationLoginPanel object:nil];
    // 初始化属性
    self.isCurrentUserAdmn = NO;
}

- (void)initializingUsers:(NSNotification *)notification {
    
    NSString *password = [notification.userInfo objectForKey:NSNotificationInfoKeyPassword];
    NSString *userName = [notification.userInfo objectForKey:NSNotificationInfoKeyUserName];
    
    if (self.isCurrentUserAdmn == YES) {
        self.user = [[QSAdministrator alloc] initWithUserID:userName password:password];
    } else {
        self.user = [[QSTester alloc] initWithUserID:userName password:password];
    }
    
    BOOL loginOK = [self.user login];
    // 如果登陆失败，弹窗提醒
    if (loginOK == NO) {
        QSLoginViewController *mvc = (QSLoginViewController *)[self.viewControllers objectAtIndex:1];
        [mvc actionPostLoginFail];
    } else {
        // 如果登陆成功，将用户信息赋值给所有的子对象
        QSLoginViewController *mvc = (QSLoginViewController *)[self.viewControllers objectAtIndex:1];
        [mvc setUsr:self.user];
        
        QSRightViewController *rvc = (QSRightViewController *)[self.viewControllers objectAtIndex:2];
        [rvc setUser:self.user];
        [mvc setUsr:self.user];
        [mvc actionPostLoginOK];
    }
}

- (void)recieveLeftPanelAction:(NSNotification *)notification {
    NSLog(@"%@ - left panel action: %@",self,notification.userInfo[NSNotificationInfoKey]);
    self.user = [[QSUser alloc] init];
    [self.user setIsLogin:NO];
    
    NSString *notifInfo = [notification.userInfo objectForKey:NSNotificationInfoKey];
    QSLoginViewController *mvc = [[QSLoginViewController alloc] initWithNibName:@"QSLoginViewController" bundle:nil];
    [mvc.view setFrame:CGRectMake(81, 0, 718, 600)];
    [self.view replaceSubview:self.view.subviews[1] with:mvc.view];
    [self.viewControllers replaceObjectAtIndex:1 withObject:mvc];
    
    if ([notifInfo isEqualToString:NSNotificationInfoStartAdmn] == YES) {
        // 中间视图：加载管理员登陆界面
        QSLoginViewController *mvc = (QSLoginViewController *)self.viewControllers[1];
        [self setIsCurrentUserAdmn:YES];
        [mvc layoutForUser:self.isCurrentUserAdmn];
        
        // 右侧视图：加载管理员功能面板
        QSRightViewController *rmv = (QSRightViewController *)self.viewControllers[2];
        [rmv layoutForAdministrator];
        [rmv.user setIsLogin:NO];
        
    } else {
        // 中间视图：加载测试登陆界面
        QSLoginViewController *mvc = (QSLoginViewController *)self.viewControllers[1];
        [self setIsCurrentUserAdmn:NO];
        [mvc layoutForUser:self.isCurrentUserAdmn];
        
        // 右侧视图：加载测试功能面板
        QSRightViewController *rmv = (QSRightViewController *)self.viewControllers[2];
        [rmv layoutForTesting];
        [rmv.user setIsLogin:NO];
    }
}

- (void)recieveRightPanelAction:(NSNotification *)notification {
    NSLog(@"%@ - right panel action: %@",self,notification.userInfo[NSNotificationInfoKey]);
    
    // 获取通知附带的信息，移除旧有的中间视图
    NSString *notifInfo = [notification.userInfo objectForKey:NSNotificationInfoKey];
    NSViewController *mvc;
    
    // 管理员设置面板：添加管理员设置视图
    if ([notifInfo isEqualToString:NSNotificationInfoAdmnSetting] == YES) {
        mvc = [[QSConfigViewController alloc] initWithUser:(QSAdministrator *)self.user];
        
    } else {
        // 管理员导入面板：添加管理员load视图
        if ([notifInfo isEqualToString:NSNotificationInfoAdmnLoading] == YES) {
            mvc = [[QSLoadingViewController alloc] initWithUser:(QSAdministrator *)self.user];
            
        } else {
            // 管理员查看面板：添加管理员查看视图
            if ([notifInfo isEqualToString:NSNotificationInfoAdmnReview] == YES) {
                mvc = [[QSReviewViewController alloc] initWithUser:(QSAdministrator *)self.user];
                
            } else {
                // 考生考试面板：添加考生考试视图
                if ([notifInfo isEqualToString:NSNotificationInfoTestTest] == YES) {
                    mvc = [[QSTestViewController alloc] initWithUsers:(QSTester *)self.user];
                    
                } else {
                    // 考生试题面板：添加考生试题视图
                    if ([notifInfo isEqualToString:NSNotificationInfoTestPaper] == YES) {
                        mvc = [[QSPaperViewController alloc] initWithUsers:(QSTester *)self.user];
                        
                    } else {
                        // 考生考试记录面板：添加考生考试视图
                        if ([notifInfo isEqualToString:NSNotificationInfoTestRecord] == YES) {
                            mvc = [[QSRecordViewController alloc] initWithUser:(QSTester *)self.user];
                        }
                    }
                }
            }
        }
    }
    
    [mvc.view setFrame:CGRectMake(81, 0, 718, 600)];
    [self.view replaceSubview:self.view.subviews[1] with:mvc.view];
    [self.viewControllers replaceObjectAtIndex:1 withObject:mvc];
}

@end
