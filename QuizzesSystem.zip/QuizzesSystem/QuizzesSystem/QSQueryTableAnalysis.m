//
//  QSQueryTableAnalysis.m
//  TestSystem
//
//  Created by SW05 on 3/7/16.
//  Copyright © 2016 TDE-SMTFA05. All rights reserved.
//

#import "QSQueryTableAnalysis.h"
#import "QSQuizAnalysis.h"
#import "QSMysql.h"

@interface QSQueryTableAnalysis ()

@property (nonatomic, strong) NSMutableArray  *dataModel;
@property (nonatomic, assign) CGFloat  totSco;
@property (nonatomic, strong) QSMysql  *mysql;
@property (nonatomic, strong) NSString *key;

@end


@implementation QSQueryTableAnalysis

- (void)prepareData:(NSString *)key mySQL:(QSMysql *)mysql {
    
    self.mysql = mysql;
    self.key   = key;
    
    [self compositeDataModel];
    
}

- (void)compositeDataModel {
    
    NSString *sheetNm = @"Test_Record_All";
    NSString *rowKey  = [NSString stringWithFormat:@"timeStmp='%@'",self.key];
    
    NSString *totSco = [self.mysql queryColumn:@"analySco" rowKey:rowKey inSheet:sheetNm];
    self.totSco = [totSco floatValue];
    
    self.dataModel = [NSMutableArray array];
    
    for (int i=0; i<10; i++) {
        
        NSString *colKeyT = [NSString stringWithFormat:@"analTtl%d",i];
        NSString *analTtl = [self.mysql queryColumn:colKeyT rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyA = [NSString stringWithFormat:@"analAns%d",i];
        NSString *analAns = [self.mysql queryColumn:colKeyA rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyC = [NSString stringWithFormat:@"analCom%d",i];
        NSString *analCom = [self.mysql queryColumn:colKeyC rowKey:rowKey inSheet:sheetNm];
        
        NSString *colKeyS = [NSString stringWithFormat:@"analSco%d",i];
        NSString *analSco = [self.mysql queryColumn:colKeyS rowKey:rowKey inSheet:sheetNm];
        
        if ([analTtl isEqualToString:@""] == YES) {
            break;
        }
        
        NSArray *quiz = @[analTtl, analAns, analCom, analSco];
        [self.dataModel addObject:quiz];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

#pragma mark - DataSource method
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return [self.dataModel count];
}

#pragma mark - Delegate method
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    
    // 1.Retrive cellView form nib
    NSArray *nibs = [[NSArray alloc] init];
    QSQuizAnalysis *cell;
    [[NSBundle mainBundle] loadNibNamed:@"QSQuiz" owner:nil topLevelObjects:&nibs];
    
    for (id nib in nibs) {
        if ([nib isMemberOfClass:[QSQuizAnalysis class]] == YES) {
            cell = nib;
        }
    }
    
    // 2.Config the cell
    NSArray *quiz = [self.dataModel objectAtIndex:row];
    
    // set values
    [cell.title         setString:quiz[0]];
    [cell.answer        setString:quiz[1]];
    [cell.gotScore      setString:quiz[3]];
    [cell.commentField  setString:quiz[2]];
    [cell.totalScore    setStringValue:[NSString stringWithFormat:@"Total: %.0f",self.totSco]];
    
    // disable buttons
    [cell.title         setEditable:NO];
    [cell.answer        setEditable:NO];
    [cell.gotScore      setEditable:NO];
    [cell.commentField  setEditable:NO];
    [cell.okBtn         setEnabled:NO];
    
    return cell;
}

#pragma mark - table view Delegate method
- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row {
    return NO;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 380.0;
}

@end
